package in.eot.com;

public class EvenOddThread {
    public static void main(String[] args) {
        Thread evenThread = new Thread(new EvenPrinter());
        Thread oddThread = new Thread(new OddPrinter());

        evenThread.start();
        oddThread.start();
    }
}

class EvenPrinter implements Runnable {
    public void run() {
        for (int i = 2; i <= 10; i += 2) {
            System.out.println("Even Thread: " + i);
            try {
                Thread.sleep(500);  // Pause for better visibility of output
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class OddPrinter implements Runnable {
    public void run() {
        for (int i = 1; i <= 10; i += 2) {
            System.out.println("Odd Thread: " + i);
            try {
                Thread.sleep(500);  // Pause for better visibility of output
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}


/*
In the above program, we have two classes, EvenPrinter and OddPrinter, which implement the Runnable interface. Each class is responsible for printing either even or odd numbers. The run() method contains the logic for printing the respective numbers using a loop.

In the main() method, we create two Thread objects, one for each printer class. We start both threads using the start() method, which initiates the execution of their respective run() methods concurrently.

The program will output the even and odd numbers alternatively, with a pause of 500 milliseconds between each number for better visibility. You may adjust the sleep duration as per your preference.

Note: Since threads run concurrently, the exact interleaving of even and odd numbers may vary on different runs of the program.

*/
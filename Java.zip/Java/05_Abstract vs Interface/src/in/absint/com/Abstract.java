package in.absint.com;

abstract class Animal {
    protected String name;
    
    public Animal(String name) {
        this.name = name;
    }
    
    public abstract void makeSound();
    
    public void sleep() {
        System.out.println(name + " is sleeping.");
    }
}

class Dog extends Animal {
    public Dog(String name) {
        super(name);
    }
    
    public void makeSound() {
        System.out.println(name + " barks.");
    }
}

class Cat extends Animal {
    public Cat(String name) {
        super(name);
    }
    
    public void makeSound() {
        System.out.println(name + " meows.");
    }
}

public class Abstract {
    public static void main(String[] args) {
        Animal dog = new Dog("Buddy");
        dog.makeSound();
        dog.sleep();
        
        Animal cat = new Cat("Whiskers");
        cat.makeSound();
        cat.sleep();
    }
}
//In the above example, `Animal` is an abstract class with an abstract method `makeSound()` and a non-abstract method `sleep()`. The `Dog` and `Cat` classes extend the `Animal` class and provide their own implementation of the `makeSound()` method. We can create instances of the `Dog` and `Cat` classes and call their methods.


//These examples illustrate the difference between an abstract class and an interface. The abstract class (`Animal`) provides a base class with some default behavior and abstract methods that must be implemented by the subclasses. On the other hand, the interface (`Shape`) defines a contract that classes must adhere to by implementing the interface methods. Classes can implement multiple interfaces but can only extend one abstract class.
package in.absint.com;

interface Shape {
    double getArea();
    double getPerimeter();
}

class Rectangle implements Shape {
    private double length;
    private double width;
    
    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }
    
    public double getArea() {
        return length * width;
    }
    
    public double getPerimeter() {
        return 2 * (length + width);
    }
}

class Circle implements Shape {
    private double radius;
    
    public Circle(double radius) {
        this.radius = radius;
    }
    
    public double getArea() {
        return Math.PI * radius * radius;
    }
    
    public double getPerimeter() {
        return 2 * Math.PI * radius;
    }
}

public class InterfaceClass {
    public static void main(String[] args) {
        Shape rectangle = new Rectangle(4, 6);
        System.out.println("Rectangle Area: " + rectangle.getArea());
        System.out.println("Rectangle Perimeter: " + rectangle.getPerimeter());
        
        Shape circle = new Circle(3);
        System.out.println("Circle Area: " + circle.getArea());
        System.out.println("Circle Perimeter: " + circle.getPerimeter());
    }
}




//In this example, we have an `interface` called `Shape`, which declares two methods: `getArea()` and `getPerimeter()`. The `Rectangle` and `Circle` classes
//implement the `Shape` interface and provide their own implementations for the interface methods. We can create instances of the `Rectangle` and `Circle` classes and call the methods defined in the `Shape` interface.

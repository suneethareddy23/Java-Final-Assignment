package in.shapes.com;

public interface Shape {
	double calculateArea();
	double calculatePerimeter();
	

}

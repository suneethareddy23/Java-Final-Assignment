package in.constcr.com;

class Parent {
    public Parent() {
        System.out.println("Parent constructor called.....");
    }
}

class Child extends Parent {
    public Child() {
        super(); // Invoke parent class constructor
        System.out.println("Child constructor called....");
    }
}

public class Constructor {
    public static void main(String[] args) {
        @SuppressWarnings("unused")
		Child child = new Child();
    }
}



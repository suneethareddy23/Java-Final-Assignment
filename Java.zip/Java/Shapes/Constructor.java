
public class Constructor {

}

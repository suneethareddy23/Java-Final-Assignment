package in.exception.com;
import java.util.Scanner;
public class Exception_Handling {

	    @SuppressWarnings("resource")
		public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        
	        try {
	            System.out.print("Enter an integer: ");
	            int number = scanner.nextInt();
	            
	            if (number < 0) {
	                throw new Exception("Negative number not allowed");
	            }
	            
	            System.out.println("Entered number: " + number);
	        } catch (Exception e) {
	            System.out.println("Exception caught: " + e.getMessage());
	        }
	        
	        scanner.close();
	    }
}



/*
 * 
In this program, we use a Scanner to read an integer input from the user. Inside the try block, we check if the number is negative (number < 0). If it is, we throw a new instance of the Exception class with a custom error message.

If an exception is thrown, the program flow transfers to the catch block, where the caught exception is stored in the variable e. We then print the error message associated with the exception using e.getMessage().

If the entered number is non-negative, it is printed to the console.

Here's an example of the program's output when a negative number is entered:

Example 1:
Enter an integer: -5
Exception caught: Negative number not allowed
And here's an example of the program's output when a non-negative number is entered:

Example 2:
Enter an integer: 10
Entered number: 10
By using exception handling, we can detect and handle exceptional situations in a controlled manner, preventing the program from crashing and providing meaningful error messages to the user.

*
*/

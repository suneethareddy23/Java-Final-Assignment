package in.binarysearch.com;
import java.util.Scanner;

public class BinarySearchAlg {

    public static void main(String[] args) {
        int[] sortedArray = {2, 5, 8, 12, 16, 23, 38, 56, 72, 91};

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the target value: ");
        int target = scanner.nextInt();

        int index = binarySearch(sortedArray, target);

        if (index != -1) {
            System.out.println("Target value found at index: " + index);
        } else {
            System.out.println("Target value not found.");
        }

        scanner.close();
    }

    public static int binarySearch(int[] arr, int target) {
        int low = 0;
        int high = arr.length - 1;

        while (low <= high) {
            int mid = (low + high) / 2;

            if (arr[mid] == target) {
                return mid;
            } else if (arr[mid] < target) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }

        return -1;
    }
}


/*

In the above program, we have a sorted array called sortedArray that contains integers in ascending order. We prompt the user to enter the target value they want to search for using the Scanner class.

The binarySearch() method implements the binary search algorithm. It takes the sorted array and the target value as input and returns the index of the target value if found, or -1 if not found. The method uses a while loop to perform the binary search by repeatedly dividing the array in half until the target value is found or the search range is exhausted.

Finally, we check the returned index and print the appropriate message indicating whether the target value was found or not.

Please note that the array sortedArray in the above program is hard-coded for simplicity. In a real-world scenario, you may need to modify the program to accept user input for the array elements or read the array from an external source.

*/
package in.prodcons.com;
import java.util.Queue;
import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();
        int capacity = 5;

        Thread producerThread = new Thread(new Producer(queue, capacity));
        Thread consumerThread = new Thread(new Consumer(queue));

        producerThread.start();
        consumerThread.start();
    }
}


/*

In the above program, we have a Producer class that implements the Runnable interface and a Consumer class that also implements the Runnable interface.

The Producer class generates random numbers using the Random class and adds them to the shared queue. It uses synchronization and the wait() and notifyAll() methods to ensure that the queue is accessed by only one thread at a time. If the queue is full, the producer thread waits for the consumer thread to consume some numbers before adding new numbers to the queue.

The Consumer class reads numbers from the queue and calculates their sum. It also uses synchronization and the wait() and notifyAll() methods to ensure that the queue is accessed by only one thread at a time. If the queue is empty, the consumer thread waits for the producer thread to produce some numbers before consuming them.

In the main() method, we create a shared queue with a capacity of 5 and create instances of the Producer and Consumer classes. We start both threads using the start() method to initiate the execution of their respective run() methods concurrently.

The program will continuously produce and consume numbers, printing the produced and consumed numbers, as well as the sum of the consumed numbers. The program runs indefinitely until manually terminated.

*/
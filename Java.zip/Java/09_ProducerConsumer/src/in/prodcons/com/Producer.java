package in.prodcons.com;

import java.util.Queue;
import java.util.Random;

class Producer implements Runnable {
    private Queue<Integer> queue;
    private int capacity;

    public Producer(Queue<Integer> queue, int capacity) {
        this.queue = queue;
        this.capacity = capacity;
    }

    public void run() {
        Random random = new Random();

        while (true) {
            synchronized (queue) {
                while (queue.size() == capacity) {
                    try {
                        queue.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                int number = random.nextInt(100);
                queue.add(number);
                System.out.println("Produced: " + number);

                queue.notifyAll();
            }

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
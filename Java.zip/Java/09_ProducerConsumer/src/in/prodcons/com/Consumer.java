package in.prodcons.com;

import java.util.Queue;

class Consumer implements Runnable {
    private Queue<Integer> queue;

    public Consumer(Queue<Integer> queue) {
        this.queue = queue;
    }

    public void run() {
        while (true) {
            synchronized (queue) {
                while (queue.isEmpty()) {
                    try {
                        queue.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                int sum = 0;
                while (!queue.isEmpty()) {
                    int number = queue.poll();
                    sum += number;
                    System.out.println("Consumed: " + number);
                }

                System.out.println("Sum: " + sum);

                queue.notifyAll();
            }

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
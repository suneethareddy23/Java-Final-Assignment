package in.procon.com;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

class Producer implements Runnable {
	private static final int MAX_VALUE = 100;
	private static final int MAX_NUMBERS = 10;
	private static final int QUEUE_CAPACITY = 10;
	private Queue<Integer> queue = new LinkedList<>();
	private Random random = new Random();
    @Override
    public void run() {
        for (int i = 0; i < MAX_NUMBERS; i++) {
            produce();
        }
    }

    private void produce() {
        synchronized (queue) {
            while (queue.size() >= QUEUE_CAPACITY) {
                try {
                    queue.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            int number = random.nextInt(MAX_VALUE);
            queue.add(number);
            System.out.println("Produced: " + number);

            queue.notifyAll();
        }
    }
}


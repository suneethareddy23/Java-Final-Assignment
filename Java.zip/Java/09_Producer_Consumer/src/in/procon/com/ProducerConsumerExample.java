package in.procon.com;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class ProducerConsumerExample {
    private static final int MAX_NUMBERS = 10;
    private static final int MAX_VALUE = 100;
    private static final int QUEUE_CAPACITY = 5;

    private Queue<Integer> queue = new LinkedList<>();
    private Random random = new Random();
    private int sum = 0;

    public static void main(String[] args) {
        ProducerConsumerExample example = new ProducerConsumerExample();
        example.start();
    }

    public void start() {
        Thread producerThread = new Thread(new Producer());
        Thread consumerThread = new Thread(new Consumer());

        producerThread.start();
        consumerThread.start();

        try {
            producerThread.join();
            consumerThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Sum of numbers: " + sum);
    }

    class Producer implements Runnable {
        @Override
        public void run() {
            for (int i = 0; i < MAX_NUMBERS; i++) {
                produce();
            }
        }

        private void produce() {
            synchronized (queue) {
                while (queue.size() >= QUEUE_CAPACITY) {
                    try {
                        queue.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                int number = random.nextInt(MAX_VALUE);
                queue.add(number);
                System.out.println("Produced: " + number);

                queue.notifyAll();
            }
        }
    }

    class Consumer implements Runnable {
        @Override
        public void run() {
            for (int i = 0; i < MAX_NUMBERS; i++) {
                consume();
            }
        }

        private void consume() {
            synchronized (queue) {
                while (queue.isEmpty()) {
                    try {
                        queue.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                int number = queue.poll();
                sum += number;
                System.out.println("Consumed: " + number);

                queue.notifyAll();
            }
        }
    }
}

package in.procon.com;

import java.util.LinkedList;
import java.util.Queue;

	   
    class Consumer implements Runnable {
    	 private static final int MAX_NUMBERS = 10;
    	 private Queue<Integer> queue = new LinkedList<>();
    	 private int sum = 0;
        @Override
        public void run() {
            for (int i = 0; i < MAX_NUMBERS; i++) {
                consume();
            }
        }

        private void consume() {
            synchronized (queue) {
                while (queue.isEmpty()) {
                    try {
                        queue.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                int number = queue.poll();
                sum += number;
                System.out.println("Consumed: " + number);

                queue.notifyAll();
                
                System.out.println("Sum of numbers: " + sum);
            }
            
        }
}

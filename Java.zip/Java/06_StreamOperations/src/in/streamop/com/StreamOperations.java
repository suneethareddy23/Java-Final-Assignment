package in.streamop.com;
import java.util.Arrays;
import java.util.List;

public class StreamOperations {
    public static void main(String[] args) {
        // Creating a large data set (list of integers)
        List<Integer> numbers = Arrays.asList(8, 2, 5, 1, 9, 3, 7, 4, 6, 10);

        // Sorting the data in ascending order
        System.out.println("Sorted numbers in ascending order:");
        numbers.stream()
                .sorted()
                .forEach(System.out::println);

        // Filtering and retrieving even numbers
        System.out.println("\nEven numbers:");
        numbers.stream()
                .filter(num -> num % 2 == 0)
                .forEach(System.out::println);

        // Filtering and retrieving numbers greater than 5
        System.out.println("\nNumbers greater than 5:");
        numbers.stream()
                .filter(num -> num > 5)
                .forEach(System.out::println);
    }
}


/*
In the above program, we create a large data set of integers using the Arrays.asList() method. Then, we utilize the Stream API to perform various operations:

1. Sorting: We use the sorted() method to sort the numbers in ascending order. The forEach() method is used to print each sorted number.

2. Filtering even numbers: We use the filter() method with a lambda expression to filter out even numbers from the data set. The forEach() method is used to print each filtered even number.

3. Filtering numbers greater than 5: We use the filter() method with a lambda expression to filter out numbers greater than 5 from the data set. The forEach() method is used to print each filtered number.

*/


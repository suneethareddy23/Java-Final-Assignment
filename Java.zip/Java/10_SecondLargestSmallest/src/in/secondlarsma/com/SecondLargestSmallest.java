package in.secondlarsma.com;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class SecondLargestSmallest {
	
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of elements: ");
        int count = scanner.nextInt();

        List<Integer> numbers = new ArrayList<>();

        System.out.println("Enter the elements:");
        for (int i = 0; i < count; i++) {
            int num = scanner.nextInt();
            numbers.add(num);
        }

        int secondLargest = findSecondLargest(numbers);
        int secondSmallest = findSecondSmallest(numbers);

        System.out.println("Second Largest: " + secondLargest);
        System.out.println("Second Smallest: " + secondSmallest);

        scanner.close();
    }

    public static int findSecondLargest(List<Integer> numbers) {
        Collections.sort(numbers);
        int size = numbers.size();
        return numbers.get(size - 2);
    }

    public static int findSecondSmallest(List<Integer> numbers) {
        Collections.sort(numbers);
        return numbers.get(1);
    }
}


/*
 * 
 * In the above program, we prompt the user to enter the number of elements they want to input. We then read the elements one by one and store them in a List called numbers. We use the Scanner class to read input from the user.

The findSecondLargest() method sorts the list in ascending order using Collections.sort() and returns the second last element (size - 2) as the second largest element.

The findSecondSmallest() method also sorts the list in ascending order and returns the second element (numbers.get(1)) as the second smallest element.

Finally, we print the second largest and second smallest elements obtained from the list.

Please note that this program assumes that the user will input a valid number of elements and integers. Additional input validation can be added as per the specific requirements of your application.

*/
